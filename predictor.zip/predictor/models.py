from django.db import models

class Prediction(models.Model):
    temperature = models.FloatField()
    dew_point = models.FloatField()
    humidity = models.FloatField()
    wind_speed = models.FloatField()
    pressure = models.FloatField()
    precipitation = models.FloatField()
    pm10 = models.FloatField()
    predicted_pm25 = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

