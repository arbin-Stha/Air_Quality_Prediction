from django.shortcuts import render
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import io
import base64
import os

# Load dataset and train model on server start
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
dataset_path = os.path.join(BASE_DIR, "C:\\Air_Quality_Index\\cleaned_weather_data1.csv")
data = pd.read_csv(dataset_path)

# Prepare data
features = ['Temperature', 'Dew Point', 'Humidity', 'Wind Speed (Kph)', 'Pressure (Hg)', 'Precipitation (mm)', 'pm10']
target = 'pm2.5'
X = data[features]
y = data[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Function to classify PM2.5 level of concern
def classify_pm25_level(pm25):
    if pm25 <= 12:
        return "Good"
    elif pm25 <= 35.4:
        return "Moderate"
    elif pm25 <= 55.4:
        return "Unhealthy for Sensitive Groups"
    elif pm25 <= 150.4:
        return "Unhealthy"
    elif pm25 <= 250.4:
        return "Very Unhealthy"
    else:
        return "Hazardous"

# Function to generate the pie chart
def generate_pie_chart(factors, values):
    # Create a pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(values, labels=factors, autopct='%1.1f%%', startangle=90)
    plt.title("Factors Affecting PM2.5")

    # Save the chart to a buffer and encode as base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    img_data = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()

    return img_data

def home(request):
    return render(request, 'predictor/home.html')

def predict_pm25(request):
    if request.method == 'POST':
        try:
            # Collect input data
            temperature = float(request.POST.get('temperature'))
            dew_point = float(request.POST.get('dew_point'))
            humidity = float(request.POST.get('humidity'))
            wind_speed = float(request.POST.get('wind_speed'))
            pressure = float(request.POST.get('pressure'))
            precipitation = float(request.POST.get('precipitation'))
            pm10 = float(request.POST.get('pm10'))

            # Prepare input for prediction
            input_data = pd.DataFrame({
                'Temperature': [temperature],
                'Dew Point': [dew_point],
                'Humidity': [humidity],
                'Wind Speed (Kph)': [wind_speed],
                'Pressure (Hg)': [pressure],
                'Precipitation (mm)': [precipitation],
                'pm10': [pm10]
            })

            # Predict PM2.5
            predicted_pm25 = model.predict(input_data)[0]

            # Classify PM2.5 level of concern
            pm25_level = classify_pm25_level(predicted_pm25)

            # Data for the pie chart
            factors = ['PM10', 'Temperature', 'Humidity', 'Wind Speed', 'Pressure', 'Precipitation', 'Dew Point']
            values = [pm10, temperature, humidity, wind_speed, pressure, precipitation, dew_point]

            # Generate the pie chart
            pie_chart_data = generate_pie_chart(factors, values)

            # Render prediction result
            return render(request, 'predictor/result.html', {
                'predicted_pm25': round(predicted_pm25, 2),
                'pm25_level': pm25_level,
                'pie_chart': pie_chart_data
            })

        except Exception as e:
            return render(request, 'predictor/home.html', {'error': 'Invalid input. Please try again.'})

    return render(request, 'predictor/home.html')
